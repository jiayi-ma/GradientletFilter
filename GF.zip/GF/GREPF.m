function [O] = GREPF(I,threshold,lambda,f,mode,n)
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%%
if(~exist('n', 'var')),
   n=10;
end

if(~exist('mode', 'var')),
    mode = 1;
end

if(~exist('f', 'var')),
    f = 1;
end

if(~exist('lambda', 'var')),
    lambda = 50;
end

if(~exist('threshold', 'var')),
    threshold = 0.05;
end
%%

    O=I;
    X=O;

    for iter=1:f
        [px, py] = computePenaltyfactors(X,threshold,lambda,n);
        X = solveLinearEquation(I, px, py, mode);
    end
    O=X;
end
%% Threshold function
function [X1,X2] = ThresholdFunction(X,n,m)

if max(X(:))<=1;
    X=X.*255;
end
if m<=1
     m=m*255;
end

X1=1./(1+(m./(X+eps)).^n);
X2=1-X1;
end
%% compute Penalty factors px and py 
function [pxo, pyo] = computePenaltyfactors(Oin,threshold,lambda,n)
   fx = diff(Oin,1,2);
   fy = diff(Oin,1,1); 
   [~,pxo] = ThresholdFunction(abs(fx),n,threshold);
   [~,pyo] = ThresholdFunction(abs(fy),n,threshold);
   pxo = lambda.*pxo;
   pyo = lambda.*pyo;
   pxo = padarray(pxo, [0 1], 'post');
   pyo = padarray(pyo, [1 0], 'post');
end
% Solve using the WLS method or the PCG method from RTV filter
function OUT = solveLinearEquation(IN, wx, wy, mode) 
% The code for constructing inhomogenious Laplacian is adapted from 
% the implementaion of the wlsFilter. 
    [r,c,~] = size(IN);
    k = r*c;
    dx = -wx(:);
    dy = -wy(:);
    B(:,1) = dx;
    B(:,2) = dy;
    d = [-r,-1];
    A = spdiags(B,d,k,k);
    e = dx;
    w = padarray(dx, r, 'pre'); w = w(1:end-r);
    s = dy;
    n = padarray(dy, 1, 'pre'); n = n(1:end-1);
    D = 1-(e+w+s+n);
    A = A + A' + spdiags(D, 0, k, k); 
    if mode==1
        L = ichol(A,struct('michol','on'));    
        [OUT, ~] = pcg(A, IN(:),0.1,100, L, L'); 
        OUT = reshape(OUT, r, c);   
    else
        OUT = A\IN(:);
        OUT = reshape(OUT, r, c);
    end     
end


