function [F,T] = GREPF_SM_F(S1,S2,threshold,lambda,f,mode,n) 

%%
% 
% if(~exist('paths', 'var')),
%     paths = '.\';
% end
% 
% if(~exist('n', 'var')),
%    n=10;
% end
% 
% if(~exist('mode', 'var')),
%     mode = 1;
% end
% 
% if(~exist('f', 'var')),
%     f = 1;
% end
% 
% if(~exist('lambda', 'var')),
%     lambda = 50;
% end
% 
% if(~exist('threshold', 'var')),
%     threshold = 0.05;
% end
% w=1;
% p=1;
% e=num2str(threshold);
% l=num2str(lambda);

tic
[A1,R1] = Filter_decomposition(S1,threshold,lambda,f,mode,n)  ;
[A2,R2] = Filter_decomposition(S2,threshold,lambda,f,mode,n)  ;
t1=toc;

% r = 5;
% sigma = 10;
tic
SA1 = Saliency_Map_Approximate(A1); 
SA2 = Saliency_Map_Approximate(A2);

%  figure,imshow(SA1,[]);
%  figure,imshow(SA2,[]);
WA1 = 0.5+0.5*(SA1-SA2);
WA2 = 0.5+0.5*(SA2-SA1);  
t2=toc;
%  figure,imshow(WA1,[]);
%  figure,imshow(WA2,[]);

tic
r = 5;
sigma = 5;
SR1 = Saliency_Map_Residual(S1,r,sigma);
SR2 = Saliency_Map_Residual(S2,r,sigma);
%  figure,imshow(SR1,[]);
%  figure,imshow(SR2,[]);
WR1 = SR1./(SR1+SR2+eps);
WR2 = SR2./(SR1+SR2+eps);
t3=toc;
%  figure,imshow(WR1,[]);
%  figure,imshow(WR2,[]);
%% ͼ����ںϺ��ع�
%���Ʋ��ں�
tic
FA = WA1.*A1 + WA2.*A2;
%  figure,imshow(FA,[]);

%�в���ں�
FR = WR1.*R1 + WR2.*R2;
% figure,imshow(FR,[]);

%ͼ���ع�
F = FA + FR;
t4=toc;
T=[t1,t2,t3,t4];

end

function [A,R] = Filter_decomposition(I,threshold,lambda,f,mode,n)   
 A = GREPF(I,threshold,lambda,f,mode,n)  ;
 R = I - A;
end

function SA = Saliency_Map_Approximate(I)
% Approximate layer saliency mapping
        mean_i = mean(I(:));
        SA = sqrt((I-mean_i).^2);% out=abs((I-mean_i).^2)
        SA = normal(SA); 
%         h = fspecial('gaussian', [2*r+1, 2*r+1],sigma);   
%         SA = imfilter(SA, h, 'symmetric');
end

function SR = Saliency_Map_Residual(I,r,sigma) 
% Residual layer saliency mapping
     Y = [-1 -2 -1; 0 0 0; 1 2 1]; % The 3*3 Sobel x and y
     X = Y';
     GX = imfilter(I, X, 'replicate');
     GY = imfilter(I, Y, 'replicate');
     G = abs(GX)+abs(GY);
     SR=G;
    % SR = normal(SR); 
     h = fspecial('gaussian', [2*r+1, 2*r+1],sigma);   
     SR = imfilter(SR, h, 'symmetric');
end
function [out] = normal(I)   
out = I;
out = (out-min(out(:)))./(max(out(:))-min(out(:)));
end


