%%
clc;
clear; 
close all;
warning off;
%% 

for number=9
    switch number
        case 1
        name='bench';
        iname='IR_37rad.bmp';
        vname='VIS_37dhvR.bmp';
        case 2
        name='bunker';
        iname='IR_bunker_g.bmp';
        vname='bunker_r.bmp';
        case 3
        name='heather';
        iname='IR_hei_vis_g.bmp';
        vname='VIS_hei_vis_r.bmp';
        case 4
        name='Kaptein_1123';
        iname='Kaptein_1123_IR.bmp';
        vname='Kaptein_1123_Vis.bmp';
        case 5
        name='Kaptein_1654';
        iname='Kaptein_1654_IR.bmp';
        vname='Kaptein_1654_Vis.bmp';
        case 6
        name='lake';
        iname='IR_lake_g.bmp';
        vname='VIS_lake_r.bmp';
        case 7
        name='Movie_18';
        iname='Movie_18_IR.bmp';
        vname='Movie_18_Vis.bmp';
        case 8
        name='sandpath';
        iname='IR_18rad.bmp';
        vname='VIS_18dhvR.bmp';
        case 9
        name='soldiers_with_jeep';
        iname='Jeep_IR.bmp';
        vname='Jeep_Vis.bmp';
        case 10
        name='FEL_images\Nato_camp_sequence';
        iname='thermal\1826i.bmp';
        vname='visual\1826v.bmp';
        case 11
        name='FEL_images\Tree_sequence';
        iname='thermal\4901i.bmp';
        vname='visual\4901v.bmp'; 
        case 12
        name='Octec';
        iname='Octec_IR.jpg';
        vname='Octec_Vis.jpg';  
        case 13
        name='Road';
        iname='Road_IR.jpg';
        vname='Road_Vis.jpg';  
        case 14
        name='Steamboat';
        iname='Steamboat_IR.jpg';
        vname='Steamboat_Vis.jpg';  
        case 15
        name='Marne_11';
        iname='Marne_11_IR.bmp';
        vname='Marne_11_Vis.bmp';   
        otherwise
        error('�������');
    end
     paths=['.\image\Experimental_Comparison_Results\',name,'\'];
    V=imread(['.\image\Experimental_Comparison_Sources\',name,'\',vname]);
    I=imread(['.\image\Experimental_Comparison_Sources\',name,'\',iname]);

[x1,y1,z1]=size(I);
    [x2,y2,z2]=size(V);
    if z1~=1
        I=rgb2gray(I);
    end
    if z2~=1
        V=rgb2gray(V);
    end
    I1 = double(I)./255;
    V1 = double(V)./255;
    %GFF
    [x,y,z]=size(I);
    IV=zeros(x,y,3);
    IV(:,:,1)=double(I);
    IV(:,:,2)=double(V);
    %ASR
    img1=I1;
    img2=V1;

    threshold=0.05;
    lambda=50;
    f=1;
    mode=1;
    n=10;
    time=zeros(11,5);

    [ProposeFusion]=GREPF_SM_F(I1,V1,threshold,lambda,f,mode,n) ;
    imshow(ProposeFusion,[]);


    
% %     figure,imshow(mat2gray(ProposeFusion)),title('propose fusion');
%     ProposeFusion=im2uint8(ProposeFusion);
%    
%     name=[fname1,'.png'];
%     figure,imshow(ProposeFusion),title(fname1);
%     imwrite(ProposeFusion,[paths,name],'png');
%     end
% %% ϡ��==��ASR ��2015==��������Ϣ��ʧ
%     sigma = 0;
%     dic_size=256; % 256 or 128
%     load(['Dictionary/D_100000_' num2str(dic_size) '_8_0.mat']); %the first sub-dictionary 'D'
%     load(['Dictionary/D_100000_' num2str(dic_size) '_8_6.mat']); %other sub-dictionaries 'Dn' and the number is 'dic_number'
%     overlap = 7;                   
%     epsilon = 0.1; 
%     C = 1.15;
%     tic
%     FU_ASR=asr_fuse(img1,img2,D,Dn,dic_number,overlap,8*C*sigma+epsilon);
%     T4=toc;
%     FU_ASR=im2uint8(FU_ASR);
%     figure,imshow(FU_ASR),title('ASR fusion');
%     name='ASR_fusion.png';
%     imwrite(FU_ASR,[paths,name],'png');
% %     if calc_metric, Result7 = Metric(I,V,FU_ASR); end
% %     metric_final(12,:)=[Result7.Total',t0_ASR];

% %% ������==��CNN 2018
%     FU_CNN = CNN(I, V);
%     FU_CNN=im2uint8(FU_CNN);
%     figure,imshow(FU_CNN),title('CNNFusion');
%     name='CNNFusion.png';
%     imwrite(FU_CNN,[paths,name],'png');


% %% ���ģ��==����߶�+ϡ�裺LPSR 2015
% level=4;
% overlap = 6;                    
% epsilon=0.1;
% load('sparsefusion/Dictionary/D_100000_256_8.mat');
% tic
% FU_LPSR = lp_sr_fuse(I1,V1,level,3,3,D,overlap,epsilon);      %LP-SR
% t0_LPSR =toc;
% FU_LPSR =im2uint8(FU_LPSR );
% figure,imshow(FU_LPSR ),title('LPSR fusion');
% name='LPSR_fusion.png';
%imwrite(FU_LPSR ,[paths,name],'png');
% if calc_metric, Result81 = Metric(I,V,FU_LPSR); end
% metric_final(13,:)=[Result81.Total',t0_LPSR];


% %% ��߶�==����������LP   1983
%     level=4;
%     tic;
%     FU_LP = lp_fuse(I1, V1, level, 3, 3);        %LP
%     T1=toc;
% %     FU_LP=im2uint8(FU_LP);
% %     figure,imshow(FU_LP),title('LP fusion');
% %     name='LP_fusion.png';
% %     imwrite(FU_LP,[paths,name],'png');
% %     % if calc_metric, Result61= Metric(I,V,FU_LP); end
% %     % metric_final(6,:)=[Result61.Total',t0_LP];
% %% ��߶�==����������RP   
%     level=4;
%     tic;
%     FU_RP = rp_fuse(I1, V1, level, 3, 3);       %RP
%     t0_RP=toc;
% %     FU_RP=im2uint8(FU_RP);
% %     figure,imshow(FU_RP,[]),title('RP fusion');
% %     name='RP_fusion.png';
% %     imwrite(FU_RP,[paths,name],'png');
% % % if calc_metric, Result62 = Metric(I,V,FU_RP); end
% % % metric_final(7,:)=[Result62.Total',t0_RP];
% %% 6.5 CVT
% level=4;
% tic;
% FU_CVT =curvelet_fuse(I1, V1, level);       %CVT
% t0_CVT=toc;
% % FU_CVT=im2uint8(FU_CVT);
% % figure,imshow(FU_CVT,[]),title('CVT fusion');
% % name='CVT_fusion.png';
% % imwrite(FU_CVT,[paths,name],'png');
% % % if calc_metric, Result65 = Metric(I,V,FU_CVT); end
% % % metric_final(10,:)=[Result65.Total',t0_CVT];
% %% 6.6 NSCT
% tic;
% FU_NSCT =nsct_fuse(I1, V1,[2,3,3,4]);       %NSCT
% T3=toc;
% % FU_NSCT=im2uint8(FU_NSCT);
% % figure,imshow(FU_NSCT,[]),title('NSCT fusion');
% % name='NSCT_fusion.png';
% % imwrite(FU_NSCT,[paths,name],'png');
% % % if calc_metric, Result66 = Metric(I,V,FU_NSCT); end
% % % metric_final(11,:)=[Result66.Total',t0_NSCT];
% % %% ��߶�==��С����DTCWT   2007
% % %% 6.4 DTCWT
% %     [m,n]=size(I1);
% %     level=4;
% %     tic;
% %     FU_DTCWT = dtcwt_fuse(I1, V1, level);       %DTCWT
% %     T2=toc;
% %     FU_DTCWT=im2uint8(FU_DTCWT(1:m,1:n));
% %     figure,imshow(FU_DTCWT),title('DTCWT fusion');
% %     name='DTCWT_fusion.png';
% %     imwrite(FU_DTCWT,[paths,name],'png');
% % %     if calc_metric, Result64 = Metric(IFU_DTCWT,VFU_DTCWT,FU_DTCWT); end
% % %     metric_final(9,:)=[Result64.Total',t0_DTCWT];
% % %% 7 SR
% % overlap = 6;                    
% % epsilon=0.1;
% % tic;
% % FU_SR=sparse_fusion(I1,V1,D,overlap,epsilon);
% % t0_SR=toc;
% % FU_SR=im2uint8(FU_SR);
% % figure,imshow(FU_SR,[]),title('SR fusion');
% % name='SR_fusion.png';
% % imwrite(FU_SR,[paths,name],'png');
% % % if calc_metric, Result7 = Metric(I,V,FU_SR); end
% % % metric_final(12,:)=[Result7.Total',t0_SR];
% % %% 8.1  LP-SR
% % %load('sparsefusion/Dictionary/D_100000_256_8.mat');
% % tic
% % FU_LPSR = lp_sr_fuse(I1,V1,level,3,3,D,overlap,epsilon);      %LP-SR
% % t0_LPSR =toc;
% % FU_LPSR =im2uint8(FU_LPSR );
% % figure,imshow(FU_LPSR ,[]),title('LPSR fusion');
% % name='LPSR_fusion.png';
% % imwrite(FU_LPSR ,[paths,name],'png');
% % % if calc_metric, Result81 = Metric(I,V,FU_LPSR); end
% % % metric_final(13,:)=[Result81.Total',t0_LPSR];
% % %% 8.2 RP-SR
% % tic
% % FU_RPSR = rp_sr_fuse(I1,V1,level,3,3,D,overlap,epsilon);     %RP-SR
% % t0_RPSR =toc;
% % FU_RPSR=im2uint8(FU_RPSR );
% % figure,imshow(FU_RPSR ,[]),title('RPSR fusion');
% % name='RPSR_fusion.png';
% % imwrite(FU_RPSR,[paths,name],'png');
% % % if calc_metric, Result82 = Metric(I,V,FU_RPSR); end
% % % metric_final(14,:)=[Result82.Total',t0_RPSR];
% % %% 8.4 DTCWT-SR
% % tic
% % FU_DTCWTSR = dtcwt_sr_fuse(I1,V1,level,D,overlap,epsilon);      %DTCWT-SR
% % t0_DTCWTSR=toc;
% % FU_DTCWTSR=im2uint8(FU_DTCWTSR);
% % figure,imshow(FU_DTCWTSR ,[]),title('DTCWTSR fusion');
% % name='DTCWTSR_fusion.png';
% % imwrite(FU_DTCWTSR,[paths,name],'png');
% % % if calc_metric, Result84 = Metric(IFU_DTCWTSR,VFU_DTCWTSR,FU_DTCWTSR); end
% % % metric_final(16,:)=[Result84.Total',t0_DTCWTSR];
% % %% 8.5 CVT-SR
% % tic
% % FU_CVTSR = curvelet_sr_fuse(I1,V1,level,D,overlap,epsilon); %CVT-SR
% % t0_CVTSR=toc;
% % FU_CVTSR=im2uint8(FU_CVTSR );
% % figure,imshow(FU_CVTSR,[]),title('CVTSR fusion');
% % name='CVTSR_fusion.png';
% % imwrite(FU_CVTSR,[paths,name],'png');
% % % if calc_metric, Result85 = Metric(I,V,FU_CVTSR); end
% % % metric_final(17,:)=[Result85.Total',t0_CVTSR];
% % %% ��߶�+ϡ�� LP-SR RP-SR  DTCWT-SR CVT-SR NSCT-SR %DWT-SR%
% % overlap = 6;                    
% % epsilon=0.1;
% % level=4;
% % %% 8.6 NSCT-SR 
% % tic
% % FU_NSCTSR = nsct_sr_fuse(I1,V1,[2],D,overlap,epsilon);         %NSCT-SR
% % t0_NSCTSR=toc;
% % FU_NSCTSR=im2uint8(FU_NSCTSR );
% % figure,imshow(FU_NSCTSR,[]),title('NSCTSR fusion');
% % name='NSCTSR_fusion.png';
% % imwrite(FU_NSCTSR,[paths,name],'png');
% % % if calc_metric, Result86 = Metric(I,V,FU_NSCTSR); end
% % % metric_final(18,:)=[Result86.Total',t0_NSCTSR];
% %% 9 MSVD 2011
% %Image Fusion technique using Multi-resolution singular Value decomposition(2011)
% %apply MSVD
% tic;
% [Y1, U1] = MSVD(I1);
% [Y2, U2] = MSVD(V1);
% %fusion starts
% X6.LL = 0.5*(Y1.LL+Y2.LL);
% D  = (abs(Y1.LH)-abs(Y2.LH)) >= 0; 
% X6.LH = D.*Y1.LH + (~D).*Y2.LH;
% D  = (abs(Y1.HL)-abs(Y2.HL)) >= 0; 
% X6.HL = D.*Y1.HL + (~D).*Y2.HL;
% D  = (abs(Y1.HH)-abs(Y2.HH)) >= 0; 
% X6.HH = D.*Y1.HH + (~D).*Y2.HH;
% %XX = [X.LL, X.LH; X.HL, X.HH];
% U = 0.5*(U1+U2);
% %apply IMSVD
% FU_MSVD = IMSVD(X6,U);
% t0_MSVD=toc;
% FU_MSVD =im2uint8(FU_MSVD);
% % figure,imshow(FU_MSVD ,[]),title('MSVD  fusion');
% % name='MSVD _fusion.png';
% % imwrite(FU_MSVD ,[paths,name],'png');
% % % % if calc_metric, Result9 = Metric(IFU_MSVD,VFU_MSVD,FU_MSVD); end
% % % % metric_final(19,:)=[Result9.Total',t0_MSVD];
% % % % xlswrite([paths,pc_name, 'metric_final.xlsx'],metric_final);
% % 
% %% �����Է���==��TSIFVS ��2016
% %ͬ����Ϊ����������Ϣ�ɼ����ݶ���Ϣ==������ͼ����Χ���кڱߺ�ģ������  
%     tic
%     N=3;
%     %��ֵ�˲�
%     Med1= medfilt2(I1, [N N]);
%     M=35;
%     h=1/(M*M)*ones(M);
%     %��ֵ�˲�
%     b1=imfilter(double(I1),double(h),'circular');
%     %�в��
%     d1=double(I1)-b1; 
%     %������ӳ��1
%     S1=(b1-double(Med1)).^2;
%     name='S1.png';
%     imwrite(mat2gray(S1),[paths,name],'png');
%     Med2= medfilt2(V1, [N N]);
%     b2=imfilter(double(V1),double(h),'circular');
%     d2=double(V1)-b2;
%     S2=(b2-double(Med2)).^2;
%         name='S2.png';
%     imwrite(mat2gray(S2),[paths,name],'png');
%     w1=S1./(S1+S2);
%     name='w1.png';
%     imwrite(mat2gray(w1),[paths,name],'png');
%     w2=S2./(S1+S2);
%     name='w2.png';
%     imwrite(mat2gray(w2),[paths,name],'png');
%     F1=double(w1).*double(d1)+double(w2).*double(d2);
%     F2=0.5*b1+0.5*b2;
%     FU_TSIFVS=double(F1)+F2;
%     T6=toc;
% %     FU_TSIFVS=im2uint8(FU_TSIFVS);
% %     figure,imshow(FU_TSIFVS),title('TSIFVS fusion');
% %     name='TSIFVS_fusion.png';
% %     imwrite(FU_TSIFVS,[paths,name],'png');
% % %     if calc_metric, Result7 = Metric(I,V,FU_ASR); end
% % %     metric_final(12,:)=[Result7.Total',t0_ASR];
% % %% ��������==�����Ż�������GTF 2016
% % %GTF==>����������Ϣ���ɼ����ݶ���Ϣ=�������˺����е��ݶ���Ϣ�Ϳɼ����е�������Ϣͬʱ��Եģ��
% tic;
% nmpdef;
% pars_irn = irntvInputPars('l1tv');
% pars_irn.adapt_epsR   = 1;
% pars_irn.epsR_cutoff  = 0.01;   % This is the percentage cutoff
% pars_irn.adapt_epsF   = 1;
% pars_irn.epsF_cutoff  = 0.05;   % This is the percentage cutoff
% pars_irn.pcgtol_ini = 1e-4;
% pars_irn.loops      = 5;
% pars_irn.U0         = I1-V1;
% pars_irn.variant       = NMP_TV_SUBSTITUTION;
% pars_irn.weight_scheme = NMP_WEIGHTS_THRESHOLD;
% pars_irn.pcgtol_ini    = 1e-2;
% pars_irn.adaptPCGtol   = 1;
% U = irntv(I1-V1, {}, 4, pars_irn);
% FU_GTF=U+V1;
% T8=toc;
% % FU_GTF=im2uint8(FU_GTF);
% % figure,imshow(FU_GTF),title('GTF fusion');
% % name='FU_GTF_fusion.png';
% % imwrite(FU_GTF,[paths,name],'png');
% % % if calc_metric, Result4 = Metric(I,V,FU_GTF); end
% % % metric_final(4,:)=[Result4.Total',t0_GTF];
% % %% ��߶�==�������˲����ͻ�Ϸ����� GFF  2013==���ݶ���Ϣ��Ϊ�����Ⱥ���������Ϣ
% %% 2 GFF 2013
%     tic
%     FU_GFF = GFF(IV);                                                              
%     T7=toc;
% %     FU_GFF=im2uint8(FU_GFF);
% %     figure,imshow(FU_GFF),title('GFF fusion');
% %     name='GFF_fusion.png';
% %     imwrite(FU_GFF,[paths,name],'png');
% % %     if calc_metric, Result2 = Metric(I,V,FU_GFF); end
% % %     metric_final(2,:)=[Result2.Total',t0_GFF];
% %% �ӿռ�==��FPDE 2017
%     tic
%     FU_FPDE=fpde_fuse(I1,V1);
%     T5=toc;
% %     FU_FPDE=im2uint8(FU_FPDE);
% %     figure,imshow(FU_FPDE),title('FPDEFusion');
% %     name='FPDEFusion.png';
% %     imwrite(FU_FPDE,[paths,name],'png');
% TIME=[T1,T2,T3,T4,T5,T6,T7,T8,T9];
 end
